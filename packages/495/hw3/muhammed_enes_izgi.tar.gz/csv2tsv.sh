#!/bin/sh
./csv2tab < input.csv > input.tsv
