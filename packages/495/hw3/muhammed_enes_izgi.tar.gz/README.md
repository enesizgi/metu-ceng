You can just run the main.py python script.
It converts the csv into a tsv.
After conversion, it copies the tsv into hdfs.
(/user/<username>/input/ directory must be present for this script to work.)
After running all of the tasks, it prints the results.

Script usage: python3 main.py input.csv