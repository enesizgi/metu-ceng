#ifndef __BVH__
#define __BVH__

// void read_jpeg_header(char *filename, int& width, int& height);

#endif //__BVH__